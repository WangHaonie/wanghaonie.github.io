#pragma once

#include <Windows.h>
#include <CommCtrl.h>
#include <Uxtheme.h>
#include "IatHook.h"

extern "C"
{
	__declspec(dllexport) void __stdcall ApplyTheme(HWND hLV, COLORREF hHForeColor);
	__declspec(dllexport) void __stdcall FlushApp(int preferredAppMode);
	__declspec(dllexport) void __stdcall FixDarkScrollBar();
}