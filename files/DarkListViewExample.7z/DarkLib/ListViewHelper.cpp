#include "pch.h"
#include "ListViewHelper.h"

using fnOpenNcThemeData = HTHEME(WINAPI*)(HWND hWnd, LPCWSTR pszClassList);
using fnSetPreferredAppMode = int(WINAPI*)(int preferredAppMode);
fnSetPreferredAppMode SetPreferredAppMode = nullptr;
fnOpenNcThemeData _OpenNcThemeData = nullptr;
static COLORREF LVHForeColor;

void FlushApp(int preferredAppMode)
{
	if (!SetPreferredAppMode)
	{
		HMODULE hUxtheme = LoadLibraryExW(L"uxtheme.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);

		if (hUxtheme)
		{
			auto addr = GetProcAddress(hUxtheme, MAKEINTRESOURCEA(135));

			if (addr)
			{
				SetPreferredAppMode = reinterpret_cast<fnSetPreferredAppMode>(addr);
			}
		}
	}

	if (SetPreferredAppMode)
	{
		SetPreferredAppMode(preferredAppMode);
	}
}

static LRESULT CALLBACK ListViewNativeWindow(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR)
{
	switch (uMsg)
	{
	case WM_NOTIFY:
	{
		if (reinterpret_cast<LPNMHDR>(lParam)->code == NM_CUSTOMDRAW)
		{
			LPNMCUSTOMDRAW nmcd = reinterpret_cast<LPNMCUSTOMDRAW>(lParam);

			switch (nmcd->dwDrawStage)
			{
			case CDDS_PREPAINT:
				return CDRF_NOTIFYITEMDRAW;
			case CDDS_ITEMPREPAINT:
				SetTextColor(nmcd->hdc, LVHForeColor);
				return CDRF_DODEFAULT;
			}
		}

		break;
	}

	case WM_NCDESTROY:
		RemoveWindowSubclass(hWnd, ListViewNativeWindow, uIdSubclass);
		break;
	}

	return DefSubclassProc(hWnd, uMsg, wParam, lParam);
}

void ApplyTheme(HWND hLV, COLORREF hHForeColor)
{
	LVHForeColor = hHForeColor;
	SetWindowSubclass(hLV, ListViewNativeWindow, reinterpret_cast<UINT_PTR>(hLV), 0);
	SetWindowTheme(ListView_GetHeader(hLV), L"DarkMode_ItemsView", nullptr);
	SetWindowTheme(hLV, L"DarkMode_ItemsView", nullptr);
}

void FixDarkScrollBar()
{
	HMODULE hComctl = LoadLibraryExW(L"comctl32.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
	if (hComctl)
	{
		auto addr = FindDelayLoadThunkInModule(hComctl, "uxtheme.dll", 49);
		if (addr)
		{
			DWORD oldProtect;
			if (VirtualProtect(addr, sizeof(IMAGE_THUNK_DATA), PAGE_READWRITE, &oldProtect))
			{
				auto MyOpenThemeData = [](HWND hWnd, LPCWSTR classList) -> HTHEME {
					if (wcscmp(classList, L"ScrollBar") == 0)
					{
						hWnd = nullptr;
						classList = L"DarkMode_Explorer::ScrollBar";
					}
					return _OpenNcThemeData(hWnd, classList);
					};

				addr->u1.Function = reinterpret_cast<ULONG_PTR>(static_cast<fnOpenNcThemeData>(MyOpenThemeData));
				VirtualProtect(addr, sizeof(IMAGE_THUNK_DATA), oldProtect, &oldProtect);
			}
		}
	}
}