﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DarkListViewExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ListView1.ForeColor = Color.White;
            ListView1.BackColor = Color.Black;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Natives.ApplyTheme(ListView1.Handle, ColorTranslator.ToWin32(Color.White));
        }
    }
}
