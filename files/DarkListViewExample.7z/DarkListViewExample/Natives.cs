﻿using System;
using System.Runtime.InteropServices;

namespace DarkListViewExample
{
    public static class Natives
    {

        [DllImport("DarkLib.dll")]
        public static extern void ApplyTheme(IntPtr hLV, int crColor);

        [DllImport("DarkLib.dll")]
        public static extern void FlushApp(int preferredAppMode);

        [DllImport("DarkLib.dll")]
        public static extern void FixDarkScrollBar();
    }
}
